function calculateInterest() {
    let principal = prompt("Enter the Loan Amount:");
    let rate = prompt("Enter the Interest Rate:");
    let time = prompt("Enter the Time in Years:");
    
    while (!principal || !rate || !time || isNaN(principal,rate,time) || parseInt(rate,time) < 1) {
      alert("Please enter all values to calculate Interest.");
      return;
    }
    
    let simpleInterest = (principal * rate * time) / 100;
    let compoundInterest = principal * (Math.pow((1 + rate / 100), time)) - principal;
    
    document.getElementById("simpleInterest").innerText = `Simple Interest: $${simpleInterest.toFixed(2)}`;
    document.getElementById("compoundInterest").innerText = `Compound Interest: $${compoundInterest.toFixed(2)}`;
  }